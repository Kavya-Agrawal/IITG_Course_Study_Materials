// ============================
// File: tcp_sim_custom.cc
// Build/Run examples:
//   ./ns3 run "scratch/tcp_sim_custom.cc --tcpType=ns3::TcpVeno"
// Variants: TcpVeno, TcpHybla, TcpNewReno, TcpHighSpeed, TcpVegas, TcpWestwood
// Topology: N0---(1Mbps/10ms, DropTail)---N1
// - FTP over TCP from N0->N1
// - 5 UDP CBR flows
// - Logs cwnd to CSV, FlowMonitor XML
// - Simulation: 2 seconds
// ============================

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include <fstream>
#include <sstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TCPVariantSim");

// Trace function for congestion window
static void TraceCwndChange(std::string context, uint32_t oldCwnd, uint32_t newCwnd)
{
    static std::ofstream cwndFile("cwnd_log.csv", std::ios::out | std::ios::trunc);
    static bool headerWritten = false;
    if (!headerWritten) {
        cwndFile << "time_s,context,old_cwnd,new_cwnd\n";
        headerWritten = true;
    }

    cwndFile << Simulator::Now().GetSeconds() << "," << context << ","
             << oldCwnd << "," << newCwnd << "\n";

    NS_LOG_INFO(Simulator::Now().GetSeconds() << "s: cwnd changed "
                                              << oldCwnd << " -> " << newCwnd
                                              << " [" << context << "]");
}

// Connect cwnd trace to all TCP sockets of Node 0
static void ConnectCwndTracer()
{
    Config::Connect("/NodeList/0/$ns3::TcpL4Protocol/SocketList/*/CongestionWindow",
                    MakeCallback(&TraceCwndChange));
}

int main(int argc, char* argv[])
{
    LogComponentEnable("TCPVariantSim", LOG_LEVEL_INFO);

    // -------------------
    // Parameters
    // -------------------
    std::string tcpType = "ns3::TcpVeno";
    double simTime = 2.0;

    CommandLine cmd;
    cmd.AddValue("tcpType", "TCP variant (ns3::TcpVeno|ns3::TcpHybla|...)", tcpType);
    cmd.AddValue("simTime", "Simulation duration (seconds)", simTime);
    cmd.Parse(argc, argv);

    Config::SetDefault("ns3::TcpL4Protocol::SocketType", StringValue(tcpType));
    NS_LOG_INFO("Using TCP variant: " << tcpType);

    // -------------------
    // Topology: 2 nodes, 1Mbps link, 10ms delay, DropTail
    // -------------------
    NodeContainer nodeList; nodeList.Create(2);

    PointToPointHelper link;
    link.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    link.SetChannelAttribute("Delay", StringValue("10ms"));
    link.SetQueue("ns3::DropTailQueue", "MaxSize", StringValue("10p"));
    NetDeviceContainer devices = link.Install(nodeList);

    InternetStackHelper stack; stack.Install(nodeList);

    Ipv4AddressHelper address; address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = address.Assign(devices);

    // -------------------
    // TCP BulkSend application
    // -------------------
    uint16_t tcpPort = 9000;
    PacketSinkHelper sinkTcp("ns3::TcpSocketFactory",
                             InetSocketAddress(Ipv4Address::GetAny(), tcpPort));
    ApplicationContainer sinkApp = sinkTcp.Install(nodeList.Get(1));
    sinkApp.Start(Seconds(0.0));
    sinkApp.Stop(Seconds(simTime));
    NS_LOG_INFO("BulkSend TCP running at port " << tcpPort);

    BulkSendHelper ftpSource("ns3::TcpSocketFactory",
                             InetSocketAddress(interfaces.GetAddress(1), tcpPort));
    ftpSource.SetAttribute("MaxBytes", UintegerValue(0)); // unlimited
    ApplicationContainer ftpApp = ftpSource.Install(nodeList.Get(0));
    ftpApp.Start(Seconds(0.0));
    ftpApp.Stop(Seconds(simTime));

    // -------------------
    // 5 UDP CBR flows
    // -------------------
    uint16_t udpBasePort = 9100;
    OnOffHelper udpFlow("ns3::UdpSocketFactory", Address());
    udpFlow.SetAttribute("DataRate", StringValue("500kbps"));
    udpFlow.SetAttribute("PacketSize", UintegerValue(1024));

    auto addCbrFlow = [&](double start, double stop, uint16_t port) {
        Address remoteAddr(InetSocketAddress(interfaces.GetAddress(1), port));
        udpFlow.SetAttribute("Remote", AddressValue(remoteAddr));
        ApplicationContainer src = udpFlow.Install(nodeList.Get(0));
        src.Start(Seconds(start)); src.Stop(Seconds(stop));

        PacketSinkHelper sinkUdp("ns3::UdpSocketFactory",
                                 InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer dst = sinkUdp.Install(nodeList.Get(1));
        dst.Start(Seconds(0.0)); dst.Stop(Seconds(simTime));
    };

    addCbrFlow(0.3, 2.0, udpBasePort + 1);
    addCbrFlow(0.5, 2.0, udpBasePort + 2);
    addCbrFlow(0.7, 1.1, udpBasePort + 3);
    addCbrFlow(0.8, 1.5, udpBasePort + 4);
    addCbrFlow(1.0, 1.6, udpBasePort + 5);

    // -------------------
    // Trace cwnd for Node 0
    // -------------------
    Simulator::Schedule(Seconds(0.1), &ConnectCwndTracer);

    // -------------------
    // Flow monitor
    // -------------------
    FlowMonitorHelper flowMonHelper;
    Ptr<FlowMonitor> monitor = flowMonHelper.InstallAll();

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    // Save XML with sanitized name
    std::string safeName = tcpType;
    for (auto &c : safeName) {
        if (!isalnum(c)) c = '_';
    }
    monitor->SerializeToXmlFile("flow_" + safeName + ".xml", true, true);

    // Print cumulative stats
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowMonHelper.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();
    uint64_t totalDrops = 0, totalRxBytes = 0;
    for (auto const &it : stats) {
        totalDrops += it.second.lostPackets;
        totalRxBytes += it.second.rxBytes;
    }
    std::cout << "== TCP Variant: " << tcpType << " ==\n";
    std::cout << "Total dropped packets: " << totalDrops << "\n";
    std::cout << "Total bytes received   : " << totalRxBytes << "\n";

    Simulator::Destroy();
    return 0;
}

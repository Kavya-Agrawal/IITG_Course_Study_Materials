#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/error-model.h"
#include "ns3/random-variable-stream.h"
#include <fstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("ABP");

// ===== ABP Packet Header =====
struct ABPPacket
{
    uint8_t sequence;
    uint8_t acknowledgement;
    uint8_t nakFlag;      // 0 = ACK, 1 = NAK
    uint16_t checksum;

    ABPPacket(uint8_t seq = 0, uint8_t ack = 0, uint8_t nak = 0)
        : sequence(seq), acknowledgement(ack), nakFlag(nak)
    {
        checksum = sequence + acknowledgement + nakFlag;
    }
};

// ===== Metrics Logger =====
class MetricsLogger : public Object
{
public:
    MetricsLogger(uint32_t packetCount)
        : m_packetCount(packetCount), m_ackedCount(0) {}

    void OnPacketAck()
    {
        m_ackedCount++;
    }

    void Log(double currentTime, uint32_t retransmitCount, std::ofstream &output)
    {
        double throughputKbps = (m_ackedCount * 8.0 * 1000) / 1e6; // Approximate kbps
        output << currentTime << "," << retransmitCount << "," << throughputKbps << "\n";
    }

private:
    uint32_t m_packetCount;
    uint32_t m_ackedCount;
};


// ---------------- Sender Application -----------------
class SenderSimulator : public Application
{
public:
    SenderSimulator();
    virtual ~SenderSimulator();

    void Initialize(Ptr<Socket> sock, Address remote, uint32_t numPackets);
    void AttachMetrics(Ptr<MetricsLogger> metrics);
    void BeginMetricsLogging(std::ofstream &logFile);

private:
    virtual void StartApplication() override;
    virtual void StopApplication() override;

    void TransmitPacket();
    void HandleIncomingPacket(Ptr<Socket> sock);
    void OnTimeout();
    void LogMetrics(std::ofstream &logFile);

    Ptr<Socket> m_socket;
    Address m_remoteAddress;
    uint32_t m_totalPackets;
    uint32_t m_packetsSent;
    EventId m_timeoutEvent;
    bool m_waitingAck;
    bool m_lastAckReceived;
    uint8_t m_currentSeq;
    uint32_t m_retransmitCount;

    Ptr<MetricsLogger> m_metricsLogger;
    EventId m_metricsEvent;
};

SenderSimulator::SenderSimulator()
    : m_socket(nullptr), m_totalPackets(0), m_packetsSent(0),
      m_waitingAck(false), m_lastAckReceived(false),
      m_currentSeq(0), m_retransmitCount(0) {}

SenderSimulator::~SenderSimulator() { m_socket = nullptr; }

void SenderSimulator::Initialize(Ptr<Socket> sock, Address remote, uint32_t numPackets)
{
    m_socket = sock;
    m_remoteAddress = remote;
    m_totalPackets = numPackets;
}

void SenderSimulator::AttachMetrics(Ptr<MetricsLogger> metrics)
{
    m_metricsLogger = metrics;
}

void SenderSimulator::BeginMetricsLogging(std::ofstream &logFile)
{
    m_metricsEvent = Simulator::Schedule(Seconds(0.5), &SenderSimulator::LogMetrics, this, std::ref(logFile));
}

void SenderSimulator::LogMetrics(std::ofstream &logFile)
{
    if (m_metricsLogger)
        m_metricsLogger->Log(Simulator::Now().GetSeconds(), m_retransmitCount, logFile);

    if (Simulator::Now().GetSeconds() < 20.0)
        m_metricsEvent = Simulator::Schedule(Seconds(0.5), &SenderSimulator::LogMetrics, this, std::ref(logFile));
}

void SenderSimulator::StartApplication()
{
    m_socket->Bind();
    m_socket->Connect(m_remoteAddress);
    m_socket->SetRecvCallback(MakeCallback(&SenderSimulator::HandleIncomingPacket, this));
    Simulator::Schedule(Seconds(0.0), &SenderSimulator::TransmitPacket, this);
}

void SenderSimulator::StopApplication()
{
    if (m_socket) m_socket->Close();
    Simulator::Cancel(m_timeoutEvent);
    Simulator::Cancel(m_metricsEvent);
    NS_LOG_UNCOND("\nSender: Total retransmissions = " << m_retransmitCount);
}

void SenderSimulator::TransmitPacket()
{
    if (m_packetsSent < m_totalPackets && !m_waitingAck)
    {
        ABPPacket pkt(m_currentSeq, 0, 0);
        Ptr<Packet> packet = Create<Packet>((uint8_t *)&pkt, sizeof(pkt));
        m_socket->Send(packet);

        NS_LOG_UNCOND("\nSender: Sent packet Seq=" << (int)m_currentSeq
                        << " at " << Simulator::Now().GetSeconds() << "s");

        m_waitingAck = true;
        m_lastAckReceived = false;
        if (m_timeoutEvent.IsRunning())
            Simulator::Cancel(m_timeoutEvent);

        m_timeoutEvent = Simulator::Schedule(Seconds(2.0), &SenderSimulator::OnTimeout, this);
    }
}

void SenderSimulator::HandleIncomingPacket(Ptr<Socket> sock)
{
    Ptr<Packet> packet = sock->Recv();
    ABPPacket pkt;
    packet->CopyData((uint8_t *)&pkt, sizeof(pkt));

    if (pkt.nakFlag)
    {
        if (pkt.acknowledgement != m_currentSeq) return;

        NS_LOG_UNCOND("Sender: Received NAK for Seq=" << (int)pkt.acknowledgement
                        << " at " << Simulator::Now().GetSeconds() << "s. Retransmitting...");
        m_waitingAck = false;
        m_retransmitCount++;
        TransmitPacket();
        return;
    }

    if (pkt.acknowledgement == m_currentSeq)
    {
        Simulator::Cancel(m_timeoutEvent);
        m_packetsSent++;
        m_currentSeq = (m_currentSeq + 1) % 2;
        m_waitingAck = false;
        m_lastAckReceived = true;

        NS_LOG_UNCOND("Sender: Received ACK for Seq=" << (int)pkt.acknowledgement
                        << " at " << Simulator::Now().GetSeconds());

        if (m_metricsLogger)
            m_metricsLogger->OnPacketAck();

        if (m_packetsSent < m_totalPackets)
            Simulator::Schedule(Seconds(0.0), &SenderSimulator::TransmitPacket, this);
        else
            NS_LOG_UNCOND("\nSender: All packets successfully transmitted.");
    }
}

void SenderSimulator::OnTimeout()
{
    if (m_lastAckReceived) return;

    NS_LOG_UNCOND("Sender: Timeout for Seq=" << (int)m_currentSeq
                    << " at " << Simulator::Now().GetSeconds() << "s. Retransmitting...");
    m_waitingAck = false;
    m_retransmitCount++;
    TransmitPacket();
}


// ---------------- Receiver Application -----------------
class ReceiverSimulator : public Application
{
public:
    ReceiverSimulator();
    virtual ~ReceiverSimulator();

    void Initialize(Ptr<Socket> sock, Ptr<RateErrorModel> errorModel);

private:
    virtual void StartApplication() override;
    virtual void StopApplication() override;

    void OnPacketReceived(Ptr<Socket> sock);

    Ptr<Socket> m_socket;
    uint8_t m_expectedSequence;
    Ptr<RateErrorModel> m_errModel;
    bool m_sentDuplicateNak;
};

ReceiverSimulator::ReceiverSimulator()
    : m_socket(nullptr), m_expectedSequence(0), m_sentDuplicateNak(false) {}

ReceiverSimulator::~ReceiverSimulator() { m_socket = nullptr; }

void ReceiverSimulator::Initialize(Ptr<Socket> sock, Ptr<RateErrorModel> errorModel)
{
    m_socket = sock;
    m_errModel = errorModel;
}

void ReceiverSimulator::StartApplication()
{
    m_socket->Bind();
    m_socket->SetRecvCallback(MakeCallback(&ReceiverSimulator::OnPacketReceived, this));
}

void ReceiverSimulator::StopApplication()
{
    if (m_socket) m_socket->Close();
}

void ReceiverSimulator::OnPacketReceived(Ptr<Socket> sock)
{
    Ptr<Packet> packet;
    Address senderAddr;

    while ((packet = sock->RecvFrom(senderAddr)))
    {
        bool isCorrupt = m_errModel->IsCorrupt(packet);

        ABPPacket pkt;
        packet->CopyData((uint8_t *)&pkt, sizeof(pkt));

        if (isCorrupt)
        {
            NS_LOG_UNCOND("Receiver: Packet corrupted! Sending NAK for Seq=" << (int)m_expectedSequence
                            << " at " << Simulator::Now().GetSeconds() << "s");
            ABPPacket nakPkt(0, m_expectedSequence, 1); 
            Ptr<Packet> nakPacket = Create<Packet>((uint8_t *)&nakPkt, sizeof(nakPkt));
            sock->SendTo(nakPacket, 0, senderAddr);
            continue;
        }

        if (pkt.sequence == m_expectedSequence)
        {
            NS_LOG_UNCOND("Receiver: Received new packet Seq=" << (int)pkt.sequence
                            << " at " << Simulator::Now().GetSeconds() << "s");
            m_expectedSequence = (m_expectedSequence + 1) % 2;

            ABPPacket ackPkt(0, pkt.sequence, 0);
            Ptr<Packet> ackPacket = Create<Packet>((uint8_t *)&ackPkt, sizeof(ackPkt));
            sock->SendTo(ackPacket, 0, senderAddr);
            NS_LOG_UNCOND("Receiver: Sent ACK=" << (int)ackPkt.acknowledgement
                            << " at " << Simulator::Now().GetSeconds() << "s");
            m_sentDuplicateNak = false;
        }
        else
        {
            if (!m_sentDuplicateNak)
            {
                NS_LOG_UNCOND("Receiver: Duplicate/out-of-order packet Seq=" << (int)pkt.sequence
                                << ". Sending NAK for Seq=" << (int)m_expectedSequence
                                << " at " << Simulator::Now().GetSeconds() << "s");
                ABPPacket nakPkt(0, m_expectedSequence, 1);
                Ptr<Packet> nakPacket = Create<Packet>((uint8_t *)&nakPkt, sizeof(nakPkt));
                sock->SendTo(nakPacket, 0, senderAddr);
                m_sentDuplicateNak = true;
            }
        }
    }
}


int main()
{
    // ----- Node Setup -----
    NodeContainer simNodes;
    simNodes.Create(2);

    PointToPointHelper p2pHelper;
    p2pHelper.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    p2pHelper.SetChannelAttribute("Delay", StringValue("10ms"));

    NetDeviceContainer devices = p2pHelper.Install(simNodes);

    InternetStackHelper internetStack;
    internetStack.Install(simNodes);

    Ipv4AddressHelper ipv4Addr;
    ipv4Addr.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = ipv4Addr.Assign(devices);

    uint16_t appPort = 78;

    // ----- Packet Loss Model -----
    Ptr<RateErrorModel> lossModel = CreateObject<RateErrorModel>();
    lossModel->SetAttribute("ErrorRate", DoubleValue(0.1)); // 10% packet loss
    lossModel->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));
    devices.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(lossModel));

    // ----- Packet Corruption Model -----
    Ptr<RateErrorModel> corruptModel = CreateObject<RateErrorModel>();
    Ptr<UniformRandomVariable> uniformVar = CreateObject<UniformRandomVariable>();
    corruptModel->SetRandomVariable(uniformVar);
    corruptModel->SetRate(0.01); // 1% corruption

    // ----- Receiver Setup -----
    Ptr<Socket> receiverSocket = Socket::CreateSocket(simNodes.Get(1), TypeId::LookupByName("ns3::UdpSocketFactory"));
    InetSocketAddress recvAddr = InetSocketAddress(Ipv4Address::GetAny(), appPort);
    receiverSocket->Bind(recvAddr);

    Ptr<ReceiverSimulator> receiverApp = CreateObject<ReceiverSimulator>();
    receiverApp->Initialize(receiverSocket, corruptModel);
    simNodes.Get(1)->AddApplication(receiverApp);
    receiverApp->SetStartTime(Seconds(0.0));
    receiverApp->SetStopTime(Seconds(20.0));

    // ----- Sender Setup -----
    Ptr<Socket> senderSocket = Socket::CreateSocket(simNodes.Get(0), TypeId::LookupByName("ns3::UdpSocketFactory"));
    Ptr<SenderSimulator> senderApp = CreateObject<SenderSimulator>();
    senderApp->Initialize(senderSocket, InetSocketAddress(interfaces.GetAddress(1), appPort), 50); // 50 packets
    simNodes.Get(0)->AddApplication(senderApp);
    senderApp->SetStartTime(Seconds(1.0));
    senderApp->SetStopTime(Seconds(20.0));

    // ----- Metrics Collection -----
    std::ofstream logFile("abp_metrics.csv");
    logFile << "Time,Retransmissions,Throughput\n";
    Ptr<MetricsLogger> metricsLogger = CreateObject<MetricsLogger>(50);
    senderApp->AttachMetrics(metricsLogger);
    senderApp->BeginMetricsLogging(logFile);

    // ----- Run Simulation -----
    Simulator::Run();
    logFile.close();
    Simulator::Destroy();

    return 0;
}

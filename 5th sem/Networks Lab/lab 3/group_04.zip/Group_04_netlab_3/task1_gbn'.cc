#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/error-model.h"
#include "ns3/random-variable-stream.h"
#include <fstream>
#include <deque>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("GBN_Sim");

constexpr uint8_t SEQ_MAX = 7; // Maximum sequence number for GBN

// ----------------- Go-Back-N Packet Header -----------------
struct PacketHeaderGBN
{
    uint8_t seqNum;
    uint16_t checksum;

    PacketHeaderGBN(uint8_t num = 0) : seqNum(num) { checksum = seqNum; }
};

// ----------------- Performance Metrics -----------------
class MetricsGBN : public Object
{
public:
    MetricsGBN(uint32_t total) 
        : m_totalPackets(total), m_ackedPackets(0), m_retxCount(0),
          m_lostPackets(0), m_windowUsage(0.0) {}

    void OnPacketAcked() { ++m_ackedPackets; }
    void OnRetransmission() { ++m_retxCount; }
    void OnPacketLost() { ++m_lostPackets; }

    void UpdateWindow(double baseSeq, double nextSeq, double winSize)
    {
        uint32_t inUse = (nextSeq >= baseSeq) ? (nextSeq - baseSeq)
                                             : (nextSeq + SEQ_MAX + 1 - baseSeq);
        m_windowUsage = static_cast<double>(inUse) / winSize;
    }

    void LogMetrics(double currentTime, std::ofstream &outFile)
    {
        double goodputKbps = (m_ackedPackets * 8.0 * 1000) / 1e6;
        outFile << currentTime << "," << m_retxCount << "," 
                << goodputKbps << "," << m_windowUsage << "," 
                << m_lostPackets << "\n";
    }

    void PrintReport() const
    {
        NS_LOG_UNCOND("\nRetransmissions: " << m_retxCount);
        NS_LOG_UNCOND("Lost packets: " << m_lostPackets);
    }

private:
    uint32_t m_totalPackets;
    uint32_t m_ackedPackets;
    uint32_t m_retxCount;
    uint32_t m_lostPackets;
    double m_windowUsage;
};

// ----------------- Go-Back-N Sender -----------------
class GbnSender : public Application
{
public:
    GbnSender();
    virtual ~GbnSender();

    void Initialize(Ptr<Socket> sock, Address peerAddr, uint32_t totalPkts, uint32_t winSize);
    void AttachMetrics(Ptr<MetricsGBN> metricsCollector);
    void BeginMetricsLogging(std::ofstream &outFile);

private:
    virtual void StartApplication() override;
    virtual void StopApplication() override;

    void DispatchPacket(uint8_t seq);
    void SendWindowPackets();
    void OnPacketReceived(Ptr<Socket> sock);
    void OnTimeout();
    void LogMetrics(std::ofstream &outFile);

    Ptr<Socket> m_sock;
    Address m_peerAddr;
    uint32_t m_totalPkts;
    uint32_t m_winSize;
    uint32_t m_baseSeq;
    uint32_t m_nextSeq;
    EventId m_timer;
    EventId m_metricsTimer;

    std::deque<Ptr<Packet>> m_buffer;
    Ptr<MetricsGBN> m_metrics;
};

GbnSender::GbnSender()
    : m_sock(nullptr), m_totalPkts(0), m_winSize(4), m_baseSeq(0), m_nextSeq(0) {}

GbnSender::~GbnSender() { m_sock = nullptr; }

void GbnSender::Initialize(Ptr<Socket> sock, Address peerAddr, uint32_t totalPkts, uint32_t winSize)
{
    m_sock = sock;
    m_peerAddr = peerAddr;
    m_totalPkts = totalPkts;
    m_winSize = winSize;
}

void GbnSender::AttachMetrics(Ptr<MetricsGBN> metricsCollector)
{
    m_metrics = metricsCollector;
}

void GbnSender::BeginMetricsLogging(std::ofstream &outFile)
{
    m_metricsTimer = Simulator::Schedule(Seconds(0.5), &GbnSender::LogMetrics, this, std::ref(outFile));
}

void GbnSender::LogMetrics(std::ofstream &outFile)
{
    if (m_metrics)
        m_metrics->LogMetrics(Simulator::Now().GetSeconds(), outFile);

    if (Simulator::Now().GetSeconds() < 20.0)
        m_metricsTimer = Simulator::Schedule(Seconds(0.5), &GbnSender::LogMetrics, this, std::ref(outFile));
}

void GbnSender::StartApplication()
{
    m_sock->Bind();
    m_sock->Connect(m_peerAddr);
    m_sock->SetRecvCallback(MakeCallback(&GbnSender::OnPacketReceived, this));

    // Create all packets in advance
    for (uint32_t i = 0; i < m_totalPkts; ++i)
    {
        PacketHeaderGBN hdr(i % (SEQ_MAX + 1));
        Ptr<Packet> pkt = Create<Packet>((uint8_t *)&hdr, sizeof(hdr));
        m_buffer.push_back(pkt);
    }

    SendWindowPackets();
}

void GbnSender::StopApplication()
{
    if (m_sock) m_sock->Close();
    Simulator::Cancel(m_timer);
    Simulator::Cancel(m_metricsTimer);

    if (m_metrics)
        m_metrics->PrintReport();
}

void GbnSender::DispatchPacket(uint8_t seq)
{
    uint32_t idx = seq;
    seq %= (SEQ_MAX + 1);
    m_sock->Send(m_buffer[idx]);
    NS_LOG_UNCOND("Sender: Sent packet seq=" << (int)seq << " at " << Simulator::Now().GetSeconds());
}

void GbnSender::SendWindowPackets()
{
    while (m_nextSeq < m_baseSeq + m_winSize && m_nextSeq < m_totalPkts)
    {
        DispatchPacket(m_nextSeq);
        if (m_baseSeq == m_nextSeq)
            m_timer = Simulator::Schedule(Seconds(2.0), &GbnSender::OnTimeout, this);

        ++m_nextSeq;
    }

    if (m_metrics)
        m_metrics->UpdateWindow(m_baseSeq, m_nextSeq, m_winSize);
}

void GbnSender::OnPacketReceived(Ptr<Socket> sock)
{
    Ptr<Packet> pkt = sock->Recv();
    PacketHeaderGBN hdr;
    pkt->CopyData((uint8_t *)&hdr, sizeof(hdr));

    uint8_t ackNum = hdr.seqNum % (SEQ_MAX + 1);
    NS_LOG_UNCOND("Sender: Received ACK for Seq=" << (int)ackNum << " at " << Simulator::Now().GetSeconds());

    while ((int)m_baseSeq % (SEQ_MAX + 1) != ((ackNum + 1) % (SEQ_MAX + 1)) && m_baseSeq < m_totalPkts)
    {
        if (m_metrics)
            m_metrics->OnPacketAcked();
        ++m_baseSeq;
    }

    if (m_baseSeq == m_nextSeq)
        Simulator::Cancel(m_timer);
    else
    {
        Simulator::Cancel(m_timer);
        m_timer = Simulator::Schedule(Seconds(2.0), &GbnSender::OnTimeout, this);
    }

    SendWindowPackets();
}

void GbnSender::OnTimeout()
{
    NS_LOG_UNCOND("\nSender: Timeout! Retransmitting from Seq=" << m_baseSeq << " at " << Simulator::Now().GetSeconds() << "\n");
    if (m_metrics)
        m_metrics->OnRetransmission();

    for (uint32_t i = m_baseSeq; i < m_nextSeq; ++i)
        DispatchPacket(i);

    m_timer = Simulator::Schedule(Seconds(2.0), &GbnSender::OnTimeout, this);
}

// ----------------- Go-Back-N Receiver -----------------
class GbnReceiver : public Application
{
public:
    GbnReceiver();
    virtual ~GbnReceiver();
    void Initialize(Ptr<Socket> sock, Ptr<RateErrorModel> errorModel, Ptr<MetricsGBN> metricsCollector);

private:
    virtual void StartApplication() override;
    virtual void StopApplication() override;
    void OnPacketReceived(Ptr<Socket> sock);

    Ptr<Socket> m_sock;
    uint32_t m_expectedSeq;
    Ptr<RateErrorModel> m_errorModel;
    Ptr<MetricsGBN> m_metrics;
};

GbnReceiver::GbnReceiver() : m_sock(nullptr), m_expectedSeq(0) {}
GbnReceiver::~GbnReceiver() { m_sock = nullptr; }

void GbnReceiver::Initialize(Ptr<Socket> sock, Ptr<RateErrorModel> errorModel, Ptr<MetricsGBN> metricsCollector)
{
    m_sock = sock;
    m_errorModel = errorModel;
    m_metrics = metricsCollector;
}

void GbnReceiver::StartApplication()
{
    m_sock->Bind();
    m_sock->SetRecvCallback(MakeCallback(&GbnReceiver::OnPacketReceived, this));
}

void GbnReceiver::StopApplication()
{
    if (m_sock) m_sock->Close();
}

void GbnReceiver::OnPacketReceived(Ptr<Socket> sock)
{
    Ptr<Packet> pkt;
    Address senderAddr;

    while ((pkt = sock->RecvFrom(senderAddr)))
    {
        bool isCorrupt = m_errorModel->IsCorrupt(pkt);

        PacketHeaderGBN hdr;
        pkt->CopyData((uint8_t *)&hdr, sizeof(hdr));

        uint8_t pktSeq = hdr.seqNum % (SEQ_MAX + 1);

        if (isCorrupt || pktSeq != (m_expectedSeq % (SEQ_MAX + 1)))
        {
            NS_LOG_UNCOND("\nReceiver: Packet lost/corrupted or out-of-order! Seq=" << (int)pktSeq
                           << ", Expected=" << (m_expectedSeq % (SEQ_MAX + 1)) 
                           << " at " << Simulator::Now().GetSeconds());
            if (m_metrics)
                m_metrics->OnPacketLost();
        }

        if (pktSeq == (m_expectedSeq % (SEQ_MAX + 1)))
        {
            NS_LOG_UNCOND("Receiver: Received in-order packet Seq=" << (int)pktSeq 
                           << " at " << Simulator::Now().GetSeconds());
            m_expectedSeq = (m_expectedSeq + 1) % (SEQ_MAX + 1);
        }

        // Send cumulative ACK
        uint8_t ackNum = (m_expectedSeq - 1 + (SEQ_MAX + 1)) % (SEQ_MAX + 1);
        PacketHeaderGBN ackHdr(ackNum);
        Ptr<Packet> ackPkt = Create<Packet>((uint8_t *)&ackHdr, sizeof(ackHdr));
        sock->SendTo(ackPkt, 0, senderAddr);
        NS_LOG_UNCOND("Receiver: Sent cumulative ACK=" << (int)ackNum << " at " << Simulator::Now().GetSeconds());
    }
}


int main()
{
    // ----------------- Create Nodes -----------------
    NodeContainer nodeList;
    nodeList.Create(2);

    // ----------------- Point-to-Point Link -----------------
    PointToPointHelper p2pHelper;
    p2pHelper.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    p2pHelper.SetChannelAttribute("Delay", StringValue("10ms"));

    NetDeviceContainer netDevices = p2pHelper.Install(nodeList);

    // ----------------- Internet Stack -----------------
    InternetStackHelper inetStack;
    inetStack.Install(nodeList);

    Ipv4AddressHelper addrHelper;
    addrHelper.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer ifaces = addrHelper.Assign(netDevices);

    uint16_t udpPort = 195;

    // ----------------- Packet Loss Model -----------------
    Ptr<RateErrorModel> pktLossModel = CreateObject<RateErrorModel>();
    pktLossModel->SetAttribute("ErrorRate", DoubleValue(0.1)); // 10% loss
    pktLossModel->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_PACKET"));
    netDevices.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(pktLossModel));

    // ----------------- Metrics -----------------
    std::ofstream metricsOut("gbn_metrics.csv");
    metricsOut << "Time,Retransmissions,Goodput,WindowUtilization,PacketLoss\n";

    Ptr<MetricsGBN> metricsCollector = CreateObject<MetricsGBN>(200);

    // ----------------- Receiver Setup -----------------
    Ptr<Socket> receiverSock = Socket::CreateSocket(nodeList.Get(1), TypeId::LookupByName("ns3::UdpSocketFactory"));
    InetSocketAddress localAddr = InetSocketAddress(Ipv4Address::GetAny(), udpPort);
    receiverSock->Bind(localAddr);

    Ptr<GbnReceiver> receiverApp = CreateObject<GbnReceiver>();
    receiverApp->Initialize(receiverSock, pktLossModel, metricsCollector);
    nodeList.Get(1)->AddApplication(receiverApp);
    receiverApp->SetStartTime(Seconds(0.0));
    receiverApp->SetStopTime(Seconds(20.0));

    // ----------------- Sender Setup -----------------
    Ptr<Socket> senderSock = Socket::CreateSocket(nodeList.Get(0), TypeId::LookupByName("ns3::UdpSocketFactory"));
    Ptr<GbnSender> senderApp = CreateObject<GbnSender>();
    senderApp->Initialize(senderSock, InetSocketAddress(ifaces.GetAddress(1), udpPort), 200, 4);
    senderApp->AttachMetrics(metricsCollector);
    senderApp->BeginMetricsLogging(metricsOut);
    nodeList.Get(0)->AddApplication(senderApp);
    senderApp->SetStartTime(Seconds(1.0));
    senderApp->SetStopTime(Seconds(20.0));

    // ----------------- Run Simulation -----------------
    Simulator::Run();
    Simulator::Destroy();

    metricsOut.close();
    return 0;
}

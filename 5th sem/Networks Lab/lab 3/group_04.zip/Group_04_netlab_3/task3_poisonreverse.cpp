//POISON REVERSE
#include <bits/stdc++.h>
using namespace std;
#define INF 100000000

void printtable(int V, vector<vector<int>> dist){
    for(int i=0; i<V; i++){
        for(int j=0; j<V; j++){
            cout << dist[i][j] << " ";
        }
        cout << "\n";
    }
}

int main()
{
    int V,E;
    cin >> V >> E;
    vector<vector<pair<int,int>>> adj(V);
    for(int i=0; i<E; i++){
        int u,v,w;
        cin >> u >> v >> w;
        adj[u].push_back({v,w});
        adj[v].push_back({u,w});
    }
    vector<vector<int>> dist(V,vector<int>(V,INF));
    for(int i=0; i<V; i++){
        dist[i][i]=0;
        for(int j=0; j<adj[i].size(); j++){
            dist[i][adj[i][j].first]=adj[i][j].second;
        }
    }
    cout << "INITIAL TABLE\n\n";
    printtable(V,dist);

    for(int q=0; q<V; q++){
        vector<vector<int>> newDist = dist;
        for(int i=0; i<V; i++){
            for(int j=0; j<adj[i].size(); j++){
                int node=adj[i][j].first;
                int cost=adj[i][j].second;
                for(int k=0; k<V; k++){
                    if(dist[i][k]>cost+dist[node][k]){
                        newDist[i][k]=cost+dist[node][k];
                    }
                }
            }
        }
        dist=newDist;
        cout << "TABLE IN ITERATION " << q << "\n"; 
        printtable(V,dist);
    }

    
    cout << "POISON REVERSE SIMULATION\n\n\n";
    int x,y;
    cin >> x >> y;

    for(int i=0; i<adj[x].size(); i++){
        if(adj[x][i].first==y) adj[x][i].second=INF;
    }
    for(int i=0; i<adj[y].size(); i++){
        if(adj[y][i].first==x) adj[y][i].second=INF;
    }

    cout << "INITIAL TABLE AFTER LINK DESTRUCTION\n\n";
    printtable(V,dist);
    
    for(int tc=0; tc<10; tc++){
        vector<vector<int>> newDist=dist;

        for(int i=0; i<V; i++){
            vector<int> minm(V,INF+1000);
            for(int j=0; j<adj[i].size(); j++){
                int node=adj[i][j].first;
                int cost=adj[i][j].second;

                if(cost!=INF){
                    for(int k=0; k<V; k++){
                        int advertiseCost = dist[node][k];

                        // Poison Reverse:
                        // If node j's best route to k is through i,
                        // then j will advertise distance to k as INF to i.
                        if(dist[node][k] == dist[node][i] + adj[node][i].second)
                            advertiseCost = INF;

                        minm[k] = min(minm[k], cost + advertiseCost);
                        if(i!=k) newDist[i][k] = minm[k];
                    }
                }
            }
        }

        dist = newDist;
        cout << "TABLE IN ITERATION " << tc << "\n";
        printtable(V,dist);
    }
    
}
//SPLIT HORIZON
#include <bits/stdc++.h>
using namespace std;
#define INF 100000000

void printtable(int V, vector<vector<int>> dist){
    for(int i=0; i<V; i++){
        for(int j=0; j<V; j++){
            cout << dist[i][j] << " ";
        }
        cout << "\n";
    }
}

int main()
{
    int V,E;
    cin >> V >> E;
    vector<vector<pair<int,int>>> adj(V);
    for(int i=0; i<E; i++){
        int u,v,w;
        cin >> u >> v >> w;
        adj[u].push_back({v,w});
        adj[v].push_back({u,w});
    }
    // distance table and next-hop table
    vector<vector<int>> dist(V,vector<int>(V,INF));
    vector<vector<int>> nextHop(V,vector<int>(V,-1)); // nextHop[i][d] = neighbor through which i reaches d

    for(int i=0; i<V; i++){
        dist[i][i]=0;
        nextHop[i][i]=i;
        for(int j=0; j<adj[i].size(); j++){
            int nb = adj[i][j].first;
            int w = adj[i][j].second;
            dist[i][nb]=w;
            nextHop[i][nb]=nb; // direct neighbor
        }
    }
    cout << "INITIAL TABLE\n\n";
    for(int i=0; i<V; i++){
        for(int j=0; j<V; j++){
            cout << dist[i][j] << " ";
        }
        cout << "\n";
    }

    // --- Iterative exchange (before any link failure) ---
    for(int q=0; q<V; q++){
        vector<vector<int>> newDist = dist;
        vector<vector<int>> newNext = nextHop;
        // each node i receives advertisements from its neighbors
        for(int i=0; i<V; i++){
            for(int idx=0; idx<adj[i].size(); idx++){
                int node = adj[i][idx].first; // neighbor sending its vector to i
                int cost = adj[i][idx].second; // cost from i -> node
                if(cost==INF) continue;
                // node advertises its dist[node][k] but implements split horizon:
                for(int k=0; k<V; k++){
                    if(k==i) continue; // destination is i (we already have dist[i][i]=0)
                    if(dist[node][k]==INF) continue; // node doesn't know route
                    // Split Horizon: node should not advertise to i a route whose nextHop at node is i
                    if(nextHop[node][k]==i) continue;
                    // candidate distance from i to k via node
                    long long cand = (long long)cost + dist[node][k];
                    if(cand >= INF) continue;
                    if(cand < newDist[i][k]){
                        newDist[i][k] = (int)cand;
                        newNext[i][k] = node; // route learned via neighbor 'node'
                    }
                }
            }
        }
        dist = newDist;
        nextHop = newNext;
        cout << "TABLE IN ITERATION " << q << "\n"; 
        printtable(V,dist);
    }
    
    
    //LINK DAMAGEEEEEEEEEEEEE
    
    
    cout << "COUNT TO INFINTY(ACCORDUING TO BOOK) WITH SPLIT HORIZON\n\n\n";
    int x,y;
    cin >> x >> y;
    // set the link cost to INF in adjacency
    for(int i=0; i<adj[x].size(); i++){
        if(adj[x][i].first==y){
            adj[x][i].second=INF;
        }
    }
    for(int i=0; i<adj[y].size(); i++){
        if(adj[y][i].first==x){
            adj[y][i].second=INF;
        }
    }
    dist[x][y]=INF;
    dist[y][x]=INF;
    if(nextHop[x][y]==y) nextHop[x][y]=-1;
    if(nextHop[y][x]==x) nextHop[y][x]=-1;

    cout << "INITIAL TABLE AFTER LINK DESTRUCTION\n\n";
    printtable(V,dist);
    
    
    for(int tc=0; tc<10; tc++){
        vector<vector<int>> newDist=dist;
        vector<vector<int>> newNext=nextHop;
        for(int i=0; i<V; i++){
            // node i receives from neighbors, but will ignore (split horizon) routes that neighbor learned via i
            vector<int> minm(V,INF+1000); // temporary minima per destination for node i
            for(int j=0; j<adj[i].size(); j++){
                
                int node=adj[i][j].first;
                int cost=adj[i][j].second;
                if(cost==INF) continue;
                // neighbor node will advertise its vector but skip entries learned via i (split horizon)
                for(int k=0; k<V; k++){
                    if(k==i) continue;
                    if(dist[node][k]==INF) continue;
                    if(nextHop[node][k]==i) continue; // SPLIT HORIZON: skip route
                    long long cand = (long long)cost + dist[node][k];
                    if(cand >= INF) continue;
                    if(cand < minm[k]) minm[k] = (int)cand;
                }
            }
            // copy minima into newDist/newNext (set nextHop to the neighbor that gave the min)
            for(int k=0; k<V; k++){
                if(k==i) continue;
                if(minm[k] < newDist[i][k]){
                    // we need to find which neighbor provided this minm[k]
                    int chosenNeighbor = -1;
                    for(int j=0; j<adj[i].size(); j++){
                        int node = adj[i][j].first;
                        int cost = adj[i][j].second;
                        if(cost==INF) continue;
                        if(dist[node][k]==INF) continue;
                        if(nextHop[node][k]==i) continue; // split horizon
                        long long cand = (long long)cost + dist[node][k];
                        if(cand == minm[k]){
                            chosenNeighbor = node;
                            break;
                        }
                    }
                    if(chosenNeighbor!=-1){
                        newDist[i][k] = minm[k];
                        newNext[i][k] = chosenNeighbor;
                    }
                }
            }
        }
        dist=newDist;
        nextHop=newNext;
        cout << "TABLE IN ITEARTION " << tc << "\n";
        printtable(V,dist);
    }

    
    
    return 0;
}